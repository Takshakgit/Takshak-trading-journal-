# TAKSHAK Trading Journal — Android project

This is the Android WebView wrapper for the local TAKSHAK Trading Journal interface.

## Build
- Android Gradle Plugin: 8.7.3
- Kotlin Android plugin: 2.0.21
- Java: 17
- Compile SDK: 35
- Minimum Android: 6.0 (API 23)

The app loads `app/src/main/assets/index.html` and its local CSS/JavaScript assets.
Trade journal data is stored locally in the WebView browser storage on the device.

## Important scope notes
Broker account integration, cloud sync/login, and AI chart analysis are not implemented in this starter project.
